var config = {
    "map": {
        "*": {
            'image-slider':'Excellence_Instagram/js/owl.carousel.min'
        }
    }
};
