require([
'jquery'
], function($){
  $('.owl-carousel').owlCarousel({

              items: 1,

                  autoplay: true,

                  dots: false,

                  nav: true,

                  navRewind: true,

                  loop: true

            });
});
