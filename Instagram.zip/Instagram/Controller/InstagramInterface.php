<?php

namespace Excellence\Instagram\Controller;

use Magento\Framework\App\ActionInterface;

interface InstagramInterface extends ActionInterface
{
}
