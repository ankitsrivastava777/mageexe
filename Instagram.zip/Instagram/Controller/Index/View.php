<?php

namespace Excellence\Instagram\Controller\Index;

use Excellence\Instagram\Controller\InstagramInterface;

class View extends \Excellence\Instagram\Controller\AbstractController\View implements InstagramInterface
{

}
