var config = {
    "paths": {
        "webp-detect": "Excellence_NextGenImages/js/detect"
    }
};